/**************************************************
 * Systematics - Exercise 2                       *
 * Template for creating systematic error bands   *
 * using the CCInclusive ntuples                  *
 **************************************************/

#include "TTree.h"
#include "TBranch.h"
#include "TFile.h"
#include "PlotUtils/MnvPlotter.h"
#include "PlotUtils/MnvH1D.h"
#include "TROOT.h"
#include "TH1.h"
#include "PlotUtils/MnvApplication.h"

using namespace std;
using namespace PlotUtils;

// We will use these data and Monte Carlo ntuples for the activity
string filename_mc="/minerva/data/users/Minerva101/rootfiles/simulation.root";
string filename_data="/minerva/data/users/Minerva101/rootfiles/data.root";


void Systematics_Solution2();

int main(int argc, char *argv[])
{
  PlotUtils::Initialize();
  Systematics_Solution2();
  return 0;
}

void Systematics_Solution2()
{
  cout<<"Enjoy MINERvA 101! This is systematics exercise 2"<<endl;

  //Load the data and Monte Carlo files
  TFile *infile_mc = new TFile(filename_mc.c_str(),"READ"); // TFile takes a c-string character array, not a C++ string
  TFile *infile_data = new TFile(filename_data.c_str(),"READ");
 
  // Your results will be stored in this output file
  string output_filename="mySystematics.root";
  TFile *out = new TFile(output_filename.c_str(),"RECREATE");
  
  // Load the CCInclusiveReco tree (ntuples) from the input root files
  TTree *tree_mc, *tree_data;
  infile_mc->GetObject("CCInclusiveReco",tree_mc);
  infile_data->GetObject("CCInclusiveReco",tree_data);


  // Our ntuple consists of many branches. As we are going to loop over the event and pick out the contents of some of them, We need to declare the ones we want to work with, using the TBranch data type.
  TBranch *b_CCInclusiveReco_leptonE; // Muon energy/momentum
  TBranch *b_wgt; // Monte Carlo central-value weight
  TBranch *b_mc_wgt_Flux_BeamFocus; // Flux beam focusing uncertainty
  TBranch *b_mc_wgt_ppfx1_Total; // New PPFX Flux uncertainty 
//  TBranch *b_mc_wgt_Flux_NA49; // Flux hadron uncertainty (from the NA49 experiment at CERN)
//  TBranch *b_mc_wgt_Flux_Tertiary; // Tertiary production flux uncertainty
  TBranch *b_CCInclusiveReco_sys_muon_energy_shift; // Shifted muon energies

  // When we loop over the ntuple, we need to load the contents of the
  // particular branches we are using into C++ variables. 
  // First we declare those variables
  double CCInclusiveReco_leptonE[4]; // Muon momentum and energy. Even though we are only using the [3] component for our plot, we have to match the data type to the ntuple branch, which is a vector of 4 numbers, [px,py,pz,E]
  double wgt; // Monte Carlo events are assigned a central-value weight based upon how likely that is to occur. That's what this is. When we generate the vertical error bands, we will do that by using alternative weights, calculated with various parameters shifted
//  double mc_wgt_Flux_Tertiary[1000]; // The ntuple includes 1000 weights corresponding to 100 tertiary flux universes
  double mc_wgt_Flux_BeamFocus[1000]; 
//  double mc_wgt_Flux_NA49[1000]; 
  double mc_wgt_ppfx1_Total[1000]; 
  double CCInclusiveReco_sys_muon_energy_shift[2]; // We have a shift up and a shift down

  // Now we need to link the branches to their respective TBranch variables, and the doubles into which we will load their contents
  tree_mc->SetBranchAddress("CCInclusiveReco_leptonE", CCInclusiveReco_leptonE, &b_CCInclusiveReco_leptonE);
  tree_mc->SetBranchAddress("wgt", &wgt, &b_wgt);
//  tree_mc->SetBranchAddress("mc_wgt_Flux_Tertiary", mc_wgt_Flux_Tertiary, &b_mc_wgt_Flux_Tertiary);
  tree_mc->SetBranchAddress("mc_wgt_ppfx1_Total", mc_wgt_ppfx1_Total, &b_mc_wgt_ppfx1_Total);
//  tree_mc->SetBranchAddress("mc_wgt_Flux_NA49", mc_wgt_Flux_NA49, &b_mc_wgt_Flux_NA49);
  tree_mc->SetBranchAddress("mc_wgt_Flux_BeamFocus", mc_wgt_Flux_BeamFocus, &b_mc_wgt_Flux_BeamFocus);
  tree_mc->SetBranchAddress("CCInclusiveReco_sys_muon_energy_shift", CCInclusiveReco_sys_muon_energy_shift, &b_CCInclusiveReco_sys_muon_energy_shift);

  // We also need the unshifted muon energy for the data histogram
  tree_data->SetBranchAddress("CCInclusiveReco_leptonE", CCInclusiveReco_leptonE, &b_CCInclusiveReco_leptonE);


  // We are also declaring these branches and variables to load the number of protons on target (POT) for the data and monte carlo. We can normalize monte carlo to data by scaling it by the ratio of the total numbers of POT, allowing us to compare the distributions
  TBranch *b_mc_pot;
  TBranch *b_numi_pot;
  double mc_pot;
  double numi_pot;
  tree_data->SetBranchAddress("numi_pot", &numi_pot, &b_numi_pot);
  tree_mc->SetBranchAddress("mc_pot", &mc_pot, &b_mc_pot);

  double total_mc_pot = 0;
  double total_data_pot = 0;
  
 
  //Create MnvH1D objects to hold the data and Monte Carlo - MnvH1D is a special collection of histograms that can hold the central value and the shifted universe histograms
  MnvH1D *h_Muon_Energy_mc = new MnvH1D("h_Muon_Energy_mc","Muon Energy (MC) ; Muon Energy (MeV); Events",30,0.0,15000);
  MnvH1D *h_Muon_Energy_data = new MnvH1D("h_Muon_Energy_data","Muon Energy (data); Muon Energy (MeV); Events",30,0.0,15000);

  //Now add the error bands.
  const int nFluxUniverses = 100; // It's quicker to just look at the first 100 than do all 1000

  // The flux uncertainties are vertical error bands, because they involve weights
  h_Muon_Energy_mc->AddVertErrorBand( "Flux_BeamFocus", nFluxUniverses );
//  h_Muon_Energy_mc->AddVertErrorBand( "Flux_Tertiary", nFluxUniverses );
//  h_Muon_Energy_mc->AddVertErrorBand( "Flux_NA49", nFluxUniverses );
  h_Muon_Energy_mc->AddVertErrorBand( "ppfx1_Total", nFluxUniverses );

  // The MINOS energy error is a lateral error band because it involves changing the actual variable we are looking at. If we were using reconstruction cuts that also depended on the muon energy, we would need to change those cuts before calculating the universes of this error band
  h_Muon_Energy_mc->AddLatErrorBand( "MINOS Energy error", 2 );
   
  // We loop over the Monte Carlo, loading the central value and shifted weights

  // Get the number of entries in the Monte Carlo tree
  long nentries_mc = tree_mc->GetEntries();
  // Loop through them
  for (long i = 0; i<nentries_mc; i++){
    tree_mc->GetEntry(i); // load the values of the i'th entry's branches into the variables you set up earlier
     // Add the POT from the Monte Carlo
     total_mc_pot += mc_pot;
     if( CCInclusiveReco_leptonE[3] == 0.0 ) continue; // Only use good data

     // Fill the central value Monte Carlo histogram
     h_Muon_Energy_mc->Fill(CCInclusiveReco_leptonE[3], wgt);
     // Now fill the universe histograms with the shifted values
     h_Muon_Energy_mc->FillVertErrorBand("Flux_BeamFocus", CCInclusiveReco_leptonE[3], mc_wgt_Flux_BeamFocus, wgt); 
//     h_Muon_Energy_mc->FillVertErrorBand("Flux_Tertiary", CCInclusiveReco_leptonE[3], mc_wgt_Flux_Tertiary, wgt); 
//     h_Muon_Energy_mc->FillVertErrorBand("Flux_NA49", CCInclusiveReco_leptonE[3], mc_wgt_Flux_NA49, wgt); 
     h_Muon_Energy_mc->FillVertErrorBand("ppfx1_Total", CCInclusiveReco_leptonE[3], mc_wgt_ppfx1_Total, wgt); 
     h_Muon_Energy_mc->FillLatErrorBand("MINOS Energy error", CCInclusiveReco_leptonE[3], CCInclusiveReco_sys_muon_energy_shift[0], CCInclusiveReco_sys_muon_energy_shift[1] );
  }


  // Finally, loop over the data ntuple to fill the data histogram 
  long nentries_data = tree_data->GetEntries();
  for (long i = 0; i<nentries_data; i++){
    tree_data->GetEntry(i);
    total_data_pot += numi_pot;
    if( CCInclusiveReco_leptonE[3] == 0.0 ) continue;
    h_Muon_Energy_data->Fill(CCInclusiveReco_leptonE[3]);
  }

  // Write the histograms to your output file and then close the file
  out->Write();
  out->Clear();
  out->Close();

  // Print out the POT numbers, make a note of these!
  total_data_pot *= 1e12;
  total_mc_pot *= 1e12;
  cout<<"Data POT = "<< total_data_pot<<endl;
  cout<<"MC POT = "<< total_mc_pot<<endl;
  cout<<"Saving plots to "<<output_filename<<endl;
  return;
}
 
